# Usage
- Run the following command,
```bash
npm start
```