# Installation
1. Clone the current repository using,
```bash
git clone https://github.com/{{param "github.owner"}}/{{param "github.repo"}}
```
2. Install the dependencies
```bash
npm install
```