# Contribution
1. If you find a bug please report the problem [here](https://github.com/{{param `github.owner`}}/{{param `github.repo`}}/issues).
2. If you wish to add a feature, make a PR [here](https://github.com/{{param `github.owner`}}/{{param `github.repo`}}/pulls)